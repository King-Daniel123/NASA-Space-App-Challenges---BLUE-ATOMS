ATOMIC SPACE - desktop edition (Windows)
Team Blue Atoms - 2026 NASA Space Apps Challenge, "Space Mission Design Game"

HOW TO RUN
1. Unzip the whole folder (keep the Assets folder next to AtomicSpace.exe).
2. Double-click AtomicSpace.exe. If Windows SmartScreen warns about an
   unknown publisher, choose "More info" > "Run anyway" (the program is not
   code-signed).

HOW TO PLAY
1. Start > pick a mission (CubeSat Pathfinder, Lunar Science Orbiter,
   Cargo Lander) and a crew size (1-4 players on one screen).
2. Build the rocket: Base / Thrusters and < > change the ship and thrusters,
   the BOOSTERS box chooses 2 or 4 boosters.
3. Read the REVIEW BOARD. RED findings block launch. AMBER ones are risks.
4. With a crew, every role ticks its sign-off (go/no-go poll).
5. LAUNCH, watch the countdown and booster separation, then continue to the
   Moon: hold the orbit, then land (SPACE, arrows / A D, M = autopilot).
6. Read the mission report: score out of 100 and why.

Numbers are simplified teaching values, not engineering data.
Source code and the browser edition:
https://github.com/King-Daniel123/NASA-Space-App-Challenges---BLUE-ATOMS
Play in the browser: https://tradespace-blue-atoms.vercel.app
